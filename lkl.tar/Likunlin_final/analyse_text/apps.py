from django.apps import AppConfig


class AnalyseTextConfig(AppConfig):
    name = 'analyse_text'
